# Jquery-Table-Check-All-Plugin

View the documentation here: https://codeanddeploy.com/blog/jquery-plugins/jquery-table-check-all-plugin
